package noobchain;
/**
 * {@code TimwWatch} This Class is non-static version of 'Timewatch'.
 */
class Timewatch {
	public long start_time;
	public long end_time;
	public float elapsed_time;
	Timewatch() {
		start_time = 0;
		end_time = 0;
		elapsed_time = 0;
	}
	public void start() { 
		start_time = System.currentTimeMillis();
	}
	public void end() { 
		end_time = System.currentTimeMillis();
	}
	public float get_elapsed_time() {
		elapsed_time = end_time - start_time;
		return elapsed_time;
	}
	public void print_elapsed_time() {
		//System.out.print("################# Elapsed Time: ");
		System.out.print(String.format("%.3f 초", get_elapsed_time()/1000)); //s
		//System.out.print(String.format("%.0f ms", get_elapsed_time())); //ms
	}
	public void print_elapsed_given_time(float time) {
		//System.out.print("################# Elapsed Time: ");
		System.out.print(String.format("%.3f 초", time/1000)); //s
		//System.out.print(String.format("%.0f ms", time)); //ms
	}
}