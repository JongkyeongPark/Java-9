package noobchain;
import java.io.*;
import java.util.ArrayList;
/**
 * {@code MakeTxt} This class is about making a text file by the input from the class 'NoobChain'
 * @author Jongkyeong Park
 *
 */
public class MakeTxt {
	/**
	 *	This method is used to make txt file with two sentences. 
	 * @param sumTime This is the first string which contains the whole working hour to make blocks. 
	 * @param averTime This is the second string which contains average value of working hour each block is made.
	 */
	public void makeT(String sumTime, String averTime) {
		String path = System.getProperty("user.dir");
		try(FileWriter fw = new FileWriter("OUTPUT.txt",true);
				BufferedWriter bw = new BufferedWriter(fw);) {
			bw.write(sumTime);
			bw.newLine();
			bw.write(averTime);
			bw.newLine();
			bw.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * This method is used to make txt file with an arrayList.
	 * @param timeCheck , this arrayList type input is contaning the time used to make each block.
	 */
	public void makeT2(ArrayList<Float> timeCheck) {
		String path = System.getProperty("user.dir");
		try(FileWriter fw = new FileWriter("forGraph.txt",true);
				BufferedWriter bw = new BufferedWriter(fw);){
			//FileWriter writer = new FileWriter("output.txt"); 
			for(Float fl: timeCheck) {
			  fw.write(fl + System.lineSeparator());
				}
			  fw.close();
			}catch (IOException e) {
				e.printStackTrace();
			}
	}
}
