package noobchain;
import java.util.ArrayList;
import com.google.gson.GsonBuilder;

//class Timewatch {
//	static long start_time;
//	static long end_time;
//	static float elapsed_time;
//	Timewatch() {
//		start_time = 0;
//		end_time = 0;
//		elapsed_time = 0;
//	}
//	static void start() { 
//		start_time = System.currentTimeMillis();
//	}
//	static void end() { 
//		end_time = System.currentTimeMillis();
//	}
//	static float get_elapsed_time() {
//		elapsed_time = end_time - start_time;
//		return elapsed_time;
//	}
//	static void print_elapsed_time() {
//		//System.out.print("################# Elapsed Time: ");
//		System.out.print(String.format("%.3f 초", get_elapsed_time()/1000)); //s
//		//System.out.print(String.format("%.0f ms", get_elapsed_time())); //ms
//	}
//	static void print_elapsed_given_time(float time) {
//		//System.out.print("################# Elapsed Time: ");
//		System.out.print(String.format("%.3f 초", time/1000)); //s
//		//System.out.print(String.format("%.0f ms", time)); //ms
//	}
//}

public class NoobChain {
	
	public static ArrayList<Block> blockchain = new ArrayList<Block>();
	public static int difficulty = 5;
	
	
	public static void main(String[] args) {	
		//add our blocks to the blockchain ArrayList:
		Timewatch timeWatcher1 = new Timewatch();
		Timewatch timeWatcher2 = new Timewatch();
		timeWatcher1.start();
		MakeTxt mt = new MakeTxt();
		// BEGIN -- 측정할 내용 시작 
		final int blocks = 100; // 블록의 개수 
		ArrayList<Float> timeCheck = new ArrayList<Float>(); 
		for(int i=0;i<blocks;i++) { // blocks변수의 값만큼의 블록을 생성한다. 
			timeWatcher2.start();
			if(i==0)
				addBlock(new Block("Hi im block"+(i+1), "0"));
			else
				addBlock(new Block("Hi im block"+(i+1), blockchain.get(blockchain.size()-1).hash));
			timeWatcher2.end();
			timeCheck.add(timeWatcher2.get_elapsed_time()/1000);
		}
		
		System.out.println("\nBlockchain is Valid: " + isChainValid());
		
		String blockchainJson = StringUtil.getJson(blockchain);
		System.out.println("\nThe block chain: ");
		System.out.println(blockchainJson);
		
		// END -- ������ ���� ��
				
		// �Ʒ� ��� ����� OUTPUT.TXT ���Ϸ� �����Ͽ� ���� ����� �Բ� �����Ͽ��� �Ѵ�.
		// OUTPUT.TXT�� ����� ���� ��� ����� �޸��忡 �ٿ��ֱ� �Ͽ� �����ص� �ȴ�.
		
		// 
		timeWatcher1.end();
		String sum = "블록 "+blocks+"개를 생성하는데 소요된 시간: "+timeWatcher1.get_elapsed_time()/1000.0;
		String aver = "블록 1개를 생성하는데 소요된 평균 시간: "+ timeWatcher1.get_elapsed_time()/((float)blocks*1000)+"초";
		System.out.println(sum);
		System.out.println(aver);
		mt.makeT(sum, aver); //txt파일로 변환.
		mt.makeT2(timeCheck);
	}
	
	public static Boolean isChainValid() {
		Block currentBlock; 
		Block previousBlock;
		String hashTarget = new String(new char[difficulty]).replace('\0', '0');
		
		//loop through blockchain to check hashes:
		for(int i=1; i < blockchain.size(); i++) {
			currentBlock = blockchain.get(i);
			previousBlock = blockchain.get(i-1);
			//compare registered hash and calculated hash:
			if(!currentBlock.hash.equals(currentBlock.calculateHash()) ){
				System.out.println("Current Hashes not equal");			
				return false;
			}
			//compare previous hash and registered previous hash
			if(!previousBlock.hash.equals(currentBlock.previousHash) ) {
				System.out.println("Previous Hashes not equal");
				return false;
			}
			//check if hash is solved
			if(!currentBlock.hash.substring( 0, difficulty).equals(hashTarget)) {
				System.out.println("This block hasn't been mined");
				return false;
			}
			
		}
		return true;
	}
	
	public static void addBlock(Block newBlock) {
		newBlock.mineBlock(difficulty);
		blockchain.add(newBlock);
	}
}